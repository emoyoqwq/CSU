#include <iostream>

using namespace std;

int main(){
    cout << "Two-one to change the light bulb and the other one accompany him\n"
            "make sure there is a new line\n";
    return 0;
}
